
public class type_cast {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="78";
		int n;
		n=Integer.parseInt(s);
		System.out.println(n);
		
		String s1,s2;
		s1="10";
		s2="20";
		System.out.println(s1+s2);
		
		int a = Integer.parseInt(s1);
		int b = Integer.parseInt(s2);
		System.out.print(a+b);
		
	}

}
